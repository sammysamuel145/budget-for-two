# Budget for Two

A small shared budget tracker (rupiah). One Node.js server, no dependencies.

## How you use it

1. Open the web address and tap "Start a new budget". You get an invitation code.
2. Tap "Copy invite message" and send it to your partner (link + code).
3. Your partner opens the link, enters the code under "Join", and you both see
   the same expenses. Pages refresh every 5 seconds.

One server can hold many budgets. Each budget is separate and only reachable
with its own 8-character invitation code.

## Run it on your computer

    node server.js

Then open http://localhost:3000. (Needs Node.js 18 or newer.)

## Put it online

Any host that runs Node.js works. Upload this folder (or connect a Git repo):

- Start command: npm start
- DATA_FILE (optional): where to keep data. Default: data.json next to server.js.

Use the https:// address your host gives you, because the invitation code is
sent with every request.

## Important: keep your data

Data lives in one JSON file. Many free hosting plans erase files when the app
restarts or redeploys. Use a plan with a persistent disk and point DATA_FILE
at it (for example /data/budget.json).

## Notes

- Anyone who has the invitation code can read and change that budget.
  Codes are random (about 800 billion possibilities) and wrong guesses are
  rate-limited (30 per 10 minutes per address), but treat the code like a password.
- Creating budgets is limited to 10 per hour per address, and 2,000 budgets total.
- There is no per-person login, so either of you can add expenses as either person.
- "Leave" only forgets the code on that device. The data stays on the server.
